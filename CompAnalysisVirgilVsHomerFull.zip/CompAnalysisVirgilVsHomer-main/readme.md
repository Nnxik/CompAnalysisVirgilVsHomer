# Computational Analysis: Iliad, Odyssey, and Aeneid

## Overview
This repository contains a suite of Natural Language Processing (NLP) experiments and computational literary analyses focused on three foundational texts of Western literature: Homer's *Iliad* and *Odyssey*, and Virgil's *Aeneid*. Using modern NLP techniques, the project explores the narrative structure, thematic composition, and semantic relationships across these epic poems.

## Project Structure
The project is divided into three primary Jupyter notebooks, each addressing a different dimension of computational literary analysis:
1. Narrative Sentiment Arcs (`sentimentarc.ipynb`)
2. Contextualized Topic Modeling (`ctmSentencelvl.ipynb` & `slurm-917467.out`)
3. Semantic Similarity and Clustering (`WordEmbeddingsandCosineSimilarityFinal.ipynb`)

* **The raw text files are located in the `data/` directory.**
* The corpus consists of text files separated by epic and chunked by book (e.g., `data/iliad/book_01.txt`, `data/aeneid/book_01.txt`). 
* Note: The data pipeline incorporates automatic summary and footnote removal functions to ensure that all analysis is performed purely on the primary narrative text.

## Requirements
The project requires Python 3 and relies on the following libraries:
- Data & Math: `numpy`, `pandas`, `scipy`
- Visualization: `matplotlib`
- NLP & Machine Learning: `nltk`, `spacy` (with `en_core_web_sm`), `scikit-learn`
- Deep Learning & Embeddings: `torch`, `sentence-transformers`
- Topic Modeling: `gensim`, `contextualized_topic_models`
- Sentiment Analysis: `vaderSentiment`
- Optimization: `optuna`
- Other: `dtaidistance`

## Getting Started
1. Ensure the `data/` directory is populated with the text files of the epics.
2. Install the required dependencies.
3. Run the notebooks in your preferred order to reproduce the sentiment arcs, topic distributions, or semantic clusterings.
